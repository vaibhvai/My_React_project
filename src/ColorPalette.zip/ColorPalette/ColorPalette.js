import React, { useState, useRef, useEffect } from "react";
import "./ColorPalette.css";
import paletteImg from './Images/palette.png'

export default function ColorPalette() {
  const [selectedColor, setSelectedColor] = useState("#FFFFFF");
  const [isPouring, setIsPouring] = useState(false);
  const [isImageLoaded, setIsImageLoaded] = useState(false);
  const [colorMix, setColorMix] = useState([]);
  const [showMaxMessage, setShowMaxMessage] = useState(false);
  const canvasRef = useRef(null);
  const imageRef = useRef(null);

  useEffect(() => {
    if (imageRef.current) {
      imageRef.current.onload = () => {
        setIsImageLoaded(true);
      };
    }
  }, []);

  const handleColorChange = (e) => {
    setIsPouring(true);
    setSelectedColor(e.target.value);
    setTimeout(() => setIsPouring(false), 500);
  };

  const handleReset = () => {
    setSelectedColor("#FFFFFF");
    setColorMix([]);
    setIsPouring(true);
    setTimeout(() => setIsPouring(false), 500);
  };

  const handleImageClick = (e) => {
    if (!isImageLoaded) return;
    
    if (colorMix.length >= 3) {
      setShowMaxMessage(true);
      setTimeout(() => setShowMaxMessage(false), 2000);
      return;
    }

    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    const img = imageRef.current;
    
    canvas.width = img.naturalWidth;
    canvas.height = img.naturalHeight;
    ctx.drawImage(img, 0, 0, img.naturalWidth, img.naturalHeight);
    
    const rect = e.target.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    const scaleX = img.naturalWidth / rect.width;
    const scaleY = img.naturalHeight / rect.height;
    
    const pixel = ctx.getImageData(x * scaleX, y * scaleY, 1, 1).data;
    const hexColor = `#${pixel[0].toString(16).padStart(2, '0')}${pixel[1].toString(16).padStart(2, '0')}${pixel[2].toString(16).padStart(2, '0')}`;
    
    const newColor = hexColor.toUpperCase();
    setSelectedColor(newColor);
    
    // Add new color with default percentage (equal distribution)
    const totalColors = colorMix.length + 1;
    const equalPercentage = Math.round(100 / totalColors);
    
    const updatedColors = [...colorMix].map(color => ({
      ...color,
      percentage: equalPercentage
    }));
    
    updatedColors.push({
      color: newColor,
      percentage: equalPercentage
    });
    
    // Adjust percentages to sum to 100
    const total = updatedColors.reduce((sum, color) => sum + color.percentage, 0);
    if (total !== 100) {
      updatedColors[0].percentage += (100 - total);
    }
    
    setColorMix(updatedColors);
    setIsPouring(true);
    setTimeout(() => setIsPouring(false), 500);
  };

  const handlePercentageChange = (index, value) => {
    const newPercentage = parseInt(value) || 0;
    if (newPercentage < 0 || newPercentage > 100) return;
    
    const updatedColors = [...colorMix];
    const oldPercentage = updatedColors[index].percentage;
    const difference = newPercentage - oldPercentage;
    
    // Distribute the difference among other colors
    const otherColors = updatedColors.filter((_, i) => i !== index);
    const totalOtherPercentage = otherColors.reduce((sum, color) => sum + color.percentage, 0);
    
    if (totalOtherPercentage === 0) {
      // If all other percentages are 0, just set this one to 100
      updatedColors.forEach((color, i) => {
        color.percentage = i === index ? 100 : 0;
      });
    } else {
      // Adjust other colors proportionally
      updatedColors[index].percentage = newPercentage;
      
      for (let i = 0; i < updatedColors.length; i++) {
        if (i !== index) {
          updatedColors[i].percentage = Math.round(
            updatedColors[i].percentage * (100 - newPercentage) / (100 - oldPercentage)
          );
        }
      }
      
      // Ensure the total is exactly 100
      const total = updatedColors.reduce((sum, color) => sum + color.percentage, 0);
      if (total !== 100) {
        const diff = 100 - total;
        for (let i = 0; i < updatedColors.length; i++) {
          if (i !== index && updatedColors[i].percentage + diff >= 0) {
            updatedColors[i].percentage += diff;
            break;
          }
        }
      }
    }
    
    setColorMix(updatedColors);
  };

  const handleImageHover = (e) => {
    if (!isImageLoaded) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    const img = imageRef.current;
    
    canvas.width = img.naturalWidth;
    canvas.height = img.naturalHeight;
    ctx.drawImage(img, 0, 0, img.naturalWidth, img.naturalHeight);
    
    const rect = e.target.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    const scaleX = img.naturalWidth / rect.width;
    const scaleY = img.naturalHeight / rect.height;
    
    const pixel = ctx.getImageData(x * scaleX, y * scaleY, 1, 1).data;
    const hexColor = `#${pixel[0].toString(16).padStart(2, '0')}${pixel[1].toString(16).padStart(2, '0')}${pixel[2].toString(16).padStart(2, '0')}`;
    
    setSelectedColor(hexColor.toUpperCase());
  };

  const getMixedColorStyle = () => {
    if (colorMix.length === 0) {
      return { background: "#FFFFFF" };
    }
    
    if (colorMix.length === 1) {
      return { background: colorMix[0].color };
    }
    
    const gradientStops = colorMix.reduce((stops, color, index) => {
      let startPercent = 0;
      if (index > 0) {
        startPercent = stops.reduce((sum, stop) => sum + stop.percent, 0);
      }
      stops.push({
        color: color.color,
        percent: color.percentage
      });
      return stops;
    }, []);
    
    const gradientString = gradientStops.map((stop, index) => {
      const start = gradientStops.slice(0, index).reduce((sum, s) => sum + s.percent, 0);
      return `${stop.color} ${start}%, ${stop.color} ${start + stop.percent}%`;
    }).join(', ');
    
    return {
      background: `linear-gradient(to right, ${gradientString})`
    };
  };

  return (
    <div className="color-picker-container">
      <h1>Color Picker</h1>
      
      <canvas ref={canvasRef} style={{ display: "none" }} />
      
      <div className="image-container">
        <img
          ref={imageRef}
             src={paletteImg}
          alt="Color Picker"
          onMouseMove={handleImageHover}
          onClick={handleImageClick}
          className="color-picker-image"
          crossOrigin="anonymous"
        />
        {!isImageLoaded && <div className="loading-message">Loading image...</div>}
      </div>
      
      <div className={`arrow ${isPouring ? "pour-animation" : ""}`}>↓</div>
      
      <div className="mixed-color-container" style={getMixedColorStyle()}>
        {colorMix.length > 0 && (
          <div className="color-percentages">
            {colorMix.map((color, index) => (
              <div key={index} className="color-percentage-control">
                <span style={{ color: getContrastColor(color.color) }}>
                  {color.percentage}%
                </span>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={color.percentage}
                  onChange={(e) => handlePercentageChange(index, e.target.value)}
                  style={{ accentColor: color.color }}
                />
              </div>
            ))}
          </div>
        )}
      </div>
      
      <button 
        className="reset-button"
        onClick={handleReset}
      >
        Reset Colors
      </button>
      
      {showMaxMessage && (
        <div className="max-message">
          Maximum of 3 colors reached!
        </div>
      )}
    </div>
  );
}

// Helper function to determine text color based on background color
function getContrastColor(hexColor) {
  const r = parseInt(hexColor.substr(1, 2), 16);
  const g = parseInt(hexColor.substr(3, 2), 16);
  const b = parseInt(hexColor.substr(5, 2), 16);
  const brightness = (r * 299 + g * 587 + b * 114) / 1000;
  return brightness > 128 ? "#000000" : "#FFFFFF";
}