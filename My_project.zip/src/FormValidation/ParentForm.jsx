import FormValidation from "./FormValidation"
import InputForm from "./InputForm"

const ParentForm =() => {
    return(
        <>
        <FormValidation/>
        </>
    )
}
export default ParentForm